import 'package:docbaorss/src/app.dart';
import 'package:flutter/material.dart';

void main() async {
  await DocBaoApp.initiate();
  runApp(DocBaoApp());
}
